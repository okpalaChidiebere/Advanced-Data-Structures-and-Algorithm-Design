/*
      Assignment 4 part 1
	  Closest Pair problem

	  purpose: To find the closest pair in a set of x,y coordinates
			   using a divide and conquer approach through recursion.

	  Input: Pre defined input file with a set number of x,y coordinates

	  output: the x,y coordinates of the closest pair and the distance between them

      assumptions and limitations: program set only to read random100points.txt and random956points.txt

*/

#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <stdio.h>
using namespace std;

const double HIGH_VALUES=999999999.00;

// structures for point and closest pair as defined////
// in class notes
struct Point{
	int x;
	int y;
};
struct closestPair{
	double dMin;
	Point p1;
	Point p2;
};
///////////////////////////////////////////////////////


//function prototypes
void selSort(Point*,Point*,int);
double Dist(Point,Point);
closestPair BruteForce(Point*,int);
closestPair Min(closestPair,closestPair);
closestPair ClosestPair(Point*,Point*,int);


/************************************************************************************************************
************************************************************************************************************/
int main(){

	// get data from user specifying file
	int n,file;
	cout << "1 - random100points.txt" << endl;
	cout << "2 - random100points.txt" << endl;
	cout << "Please choose the input file:";
	cin >> file;


	// open input file
	ifstream inputs;
	if(file==1){
		inputs.open("random100points.txt");
		n=100;
	}else if(file==2){
		inputs.open("random956points.txt");
		n=956;
	}else{
		cout << "Error. Incorrect selection.";
		return 1;
	}

	// point array initializations to read inputs
	Point *pX = new Point[n];
	Point *pY = new Point[n];


	// get input from file and save to pX and pY
	for(int i=0;i<n;i++)
	{
		int temp;
		inputs >> temp;
		pX[i].x = temp;
		pY[i].x = temp;
		inputs >> temp;
		pX[i].y = temp;
		pY[i].y = temp;
	}

	// sort both arrays
	selSort(pX,pY,n);


	// call closestpair function
	closestPair clP;
	clP = ClosestPair(pX,pY,n);

	//output results
	cout << endl << "Closest pair is" << endl;
	cout << "Point 1: " << clP.p1.x << "," <<clP.p1.y << endl;
	cout << "Point 2: " << clP.p2.x << "," <<clP.p2.y << endl;
	cout << "Distance is: " << clP.dMin << endl;


	system("PAUSE");
	return 0;

}
/************************************************************************************************************
************************************************************************************************************/


/////////////////////////////////////////////////////////////////////////////
//selSort function
//
//purpose: 
//
//inputs: two point objects
//
//output: distance between the two points in float
/////////////////////////////////////////////////////////////////////////////

void selSort(Point* pX,Point* pY,int n)
{
	for(int x=0; x<n; x++)
	{
		int index_of_min = x;
		for(int y=x; y<n; y++)
		{
			if(pX[index_of_min].x>pX[y].x)
			{
				index_of_min = y;
			}
		}
		int temp = pX[x].x;
		int temp2 = pX[x].y;

		pX[x].x = pX[index_of_min].x;
		pX[x].y = pX[index_of_min].y;

		pX[index_of_min].x = temp;
		pX[index_of_min].y = temp2;

	}


	for(int x=0; x<n; x++)
	{
		int index_of_min = x;
		for(int y=x; y<n; y++)
		{
			if(pY[index_of_min].y>pY[y].y)
			{
				index_of_min = y;
			}
		}
		int temp = pY[x].x;
		int temp2 = pY[x].y;

		pY[x].x = pY[index_of_min].x;
		pY[x].y = pY[index_of_min].y;

		pY[index_of_min].x = temp;
		pY[index_of_min].y = temp2;

	}

}
/////////////////////////////////////////////////////////////////////////////
//Dist function
//taken from CS340 algorithms page
//
//inputs: two point objects
//
//output: distance between the two points in float
/////////////////////////////////////////////////////////////////////////////

double Dist(Point p1,Point p2){
	double dX,dY;
	dX = ((double)p1.x - (double)p2.x);
	dX = dX*dX;
	dY = ((double)p1.y - (double)p2.y);
	dY = dY*dY;
	return(sqrt(dX+dY));
}


/////////////////////////////////////////////////////////////////////////////
//BruteForce function
//taken from CS340 algorithms page
//
//purpose: find the closest pair between an array of points 
//         WITHOUT using divide and conquer method
//
//inputs: array of points, int value (number of points)
//
//output: closest pair between points
/////////////////////////////////////////////////////////////////////////////
closestPair BruteForce(Point* pX,int n){
	closestPair clP;
	if(n==1)
		clP.dMin = HIGH_VALUES;
	else
	{
		double d;
		d = Dist(pX[0],pX[1]);
		clP.dMin = d;
		clP.p1.x = pX [0].x;
		clP.p1.y = pX [0].y;
		clP.p2.x = pX [1].x;
		clP.p2.y = pX [1].y;
		if(n==3)
		{
			d = Dist(pX[0],pX[2]);
			if(d < clP.dMin)
			{
				clP.dMin = d;
				clP.p2.x = pX [2].x;
				clP.p2.y = pX [2].y;
			}
			d = Dist (pX [1], pX [2]);
			if(d < clP.dMin)
			{
				clP.dMin = d;
				clP.p1.x = pX [1].x;
				clP.p1.y = pX [1].y;
				clP.p2.x = pX [2].x;
				clP.p2.y = pX [2].y;
			}
		}
	}
	return clP;
}

/////////////////////////////////////////////////////////////////////////////
//Min function
//taken from CS340 algorithms page
//
//purpose: find the closest minumum length between two closest pair objects
//
//inputs: two closestPair objects
//
//output: one closest pair object
/////////////////////////////////////////////////////////////////////////////
closestPair Min(closestPair clPL,closestPair clPR){

	closestPair clP;
	if (clPL.dMin < clPR.dMin)
	{
		clP.dMin = clPL.dMin;
		clP.p1.x = clPL.p1.x;
		clP.p1.y = clPL.p1.y;
		clP.p2.x = clPL.p2.x;
		clP.p2.y = clPL.p2.y;
	}
	else
	{
		clP.dMin = clPR.dMin;
		clP.p1.x = clPR.p1.x;
		clP.p1.y = clPR.p1.y;
		clP.p2.x = clPR.p2.x;
		clP.p2.y = clPR.p2.y;
	}
	return clP;
}



/////////////////////////////////////////////////////////////////////////////
//ClosestPair function
//taken from CS340 algorithms page
//
//purpose: find the closest pair between an array of points
//
//inputs: two array of points, int value (number of points)
//
//output: closest pair between points
/////////////////////////////////////////////////////////////////////////////
closestPair ClosestPair(Point* pX,Point* pY,int n){

	// initializations as specified in class notes
	closestPair clP;
	closestPair clPR;
	closestPair clPL;
	Point *pXL = new Point[n];
	Point *pXR = new Point[n];
	Point *pYL = new Point[n];
	Point *pYR = new Point[n];
	Point *pYC = new Point[n];


	if(n<=3)
		clP=BruteForce(pX,n);
	else{

		int middle = (n - 1) / 2;
		int x = pX[middle].x;
		int y = pX[middle].y;
		for(int i = 0; i <= middle; i++)
		{
			pXL[i].x = pX[i].x;
			pXL[i].y = pX[i].y;
		}
		int j = 0;
		for(int i = (middle + 1); i <= (n-1) ;i++)
		{
			pXR[j].x = pX[i].x;
			pXR[j].y = pX[i].y;
			j++;
		}
		int temp = j-1;
		j = 0;
		int k = 0;
		for(int i = 0; i <= (n-1); i++)
		{
			if(pY[i].x < x || (pY[i].x == x && pY[i].y <= y && j <= middle))
			{
				pYL[j].x = pY [i].x;
				pYL[j].y = pY [i].y;
				j++;
			}
			else
			{
				pYR[k].x = pY[i].x;
				pYR[k].y = pY[i].y;
				k++;
			}
		}


		clPL = ClosestPair(pXL, pYL, middle);
		clPR = ClosestPair(pXR, pYR, temp);
		clP = Min(clPL, clPR);


		j = 0;
		for(int i = 0; i <= (n-1); i++)
		{
			if(((pY[i].x) >= (x - clP.dMin)) && ((pY[i].x) <= (x + clP.dMin)) && ((abs((double)pY[i].x - (double)x)) <= (clP.dMin)))
			{
				pYC[j].x = pY[i].x;
				pYC[j].y = pY[i].y;
				j++;
			}
		}
		k = j;
		for(int i = 0; i <= (k-2); i++)
		{
			for(j = i + 1; j <= (k - 1) ;j++)
			{
				if(abs((double)pYC[j].y - (double)pYC[i].y) > clP.dMin)
					goto stp;
				double d = Dist (pYC [i], pYC [j]);
				if(d < clP.dMin)
				{
					clP.dMin = d;
					clP.p1.x = pYC [i].x;
					clP.p1.y = pYC [i].y;
					clP.p2.x = pYC [j].x;
					clP.p2.y = pYC [j].y;
				}
			}
stp:true;
		}




	}


	return clP;
}